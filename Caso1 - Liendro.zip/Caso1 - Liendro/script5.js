let productos = [];
let idEditando = null;
let idAEliminar = null;

var _guardados = localStorage.getItem("productos");
if (_guardados) {
  productos = JSON.parse(_guardados);
} else {
  productos = [
    {
      id: 1,
      nombre: "Notebook Lenovo",
      precio: 650000,
      stock: 15,
      activo: true,
      fechaIngreso: "2026-06-01",
      categorias: ["Computación", "Portátiles"],
      proveedor: { id: 101, nombre: "TecnoChile" }
    }
  ];
}

function guardarStorage() {
  localStorage.setItem("productos", JSON.stringify(productos));
}

function nuevoId() {
  if (productos.length === 0) return 1;
  let maxId = 0;
  for (let i = 0; i < productos.length; i++) {
    if (productos[i].id > maxId) {
      maxId = productos[i].id;
    }
  }
  return maxId + 1;
}




function renderizar() {
  renderizarStats();
  renderizarTabla(productos);
}

function renderizarStats() {
  let total = productos.length;
  let activos = 0;
  let stockTotal = 0;
  let valorTotal = 0;

  for (let i = 0; i < productos.length; i++) {
    let p = productos[i];
    if (p.activo) activos++;
    stockTotal += p.stock;
    valorTotal += p.precio * p.stock;
  }

  document.getElementById("stat-total").textContent = total;
  document.getElementById("stat-activos").textContent = activos;
  document.getElementById("stat-stock").textContent = stockTotal;
  document.getElementById("stat-valor").textContent = "$" + Math.round(valorTotal / 1000) + "K";
}

function renderizarTabla(lista) {
  let tbody = document.getElementById("cuerpo-tabla");
  let mensajeVacio = document.getElementById("mensaje-vacio");

  if (lista.length === 0) {
    tbody.innerHTML = "";
    mensajeVacio.style.display = "block";
    return;
  }

  mensajeVacio.style.display = "none";
  tbody.innerHTML = "";

  for (let i = 0; i < lista.length; i++) {
    let p = lista[i];

    
    let categoriasHtml = "";
    for (let j = 0; j < p.categorias.length; j++) {
      categoriasHtml += '<span class="categoria">' + p.categorias[j] + '</span>';
    }

    
    let proveedorHtml = "—";
    if (p.proveedor) {
      proveedorHtml = p.proveedor.nombre + "<br><small style='color:#999'>ID " + p.proveedor.id + "</small>";
    }

    
    let estadoHtml = p.activo
      ? '<span class="activo">Activo</span>'
      : '<span class="inactivo">Inactivo</span>';

   
    let stockHtml = p.stock;
    if (p.stock < 5) {
      stockHtml = '<span class="stock-bajo">' + p.stock + ' ⚠</span>';
    }

    
    let fecha = "—";
    if (p.fechaIngreso) {
      let partes = p.fechaIngreso.split("-");
      fecha = partes[2] + "/" + partes[1] + "/" + partes[0];
    }

    
    let textoToggle = p.activo ? "🔒" : "🔓";

    let fila = document.createElement("tr");
    fila.innerHTML =
      '<td style="color:#999; font-size:11px;">#' + p.id + '</td>' +
      '<td><strong>' + p.nombre + '</strong><div style="font-size:11px; color:#999;">' + fecha + '</div></td>' +
      '<td><strong>$' + p.precio.toLocaleString("es-CL") + '</strong></td>' +
      '<td>' + stockHtml + '</td>' +
      '<td>' + categoriasHtml + '</td>' +
      '<td>' + proveedorHtml + '</td>' +
      '<td>' + estadoHtml + '</td>' +
      '<td style="text-align:right">' +
        '<button onclick="abrirModal(' + p.id + ')" title="Editar">✏️</button> ' +
        '<button onclick="toggleActivo(' + p.id + ')" title="Cambiar estado">' + textoToggle + '</button> ' +
        '<button class="btn-rojo" onclick="pedirConfirmacion(' + p.id + ')" title="Eliminar">🗑️</button>' +
      '</td>';

    tbody.appendChild(fila);
  }
}




function buscarProductos() {
  let termino = document.getElementById("buscar").value.toLowerCase();

  if (termino === "") {
    renderizarTabla(productos);
    return;
  }

  let resultados = [];
  for (let i = 0; i < productos.length; i++) {
    let p = productos[i];
    let enNombre = p.nombre.toLowerCase().includes(termino);
    let enCategoria = false;
    let enProveedor = p.proveedor && p.proveedor.nombre.toLowerCase().includes(termino);

    for (let j = 0; j < p.categorias.length; j++) {
      if (p.categorias[j].toLowerCase().includes(termino)) {
        enCategoria = true;
      }
    }

    if (enNombre || enCategoria || enProveedor) {
      resultados.push(p);
    }
  }

  renderizarTabla(resultados);
}




function abrirModal(id) {
  idEditando = id || null;
  document.getElementById("fondo-modal").style.display = "block";

  if (id) {
    
    let producto = null;
    for (let i = 0; i < productos.length; i++) {
      if (productos[i].id === id) {
        producto = productos[i];
        break;
      }
    }
    if (!producto) return;

    document.getElementById("titulo-modal").textContent = "Editar producto";
    document.getElementById("f-nombre").value = producto.nombre;
    document.getElementById("f-precio").value = producto.precio;
    document.getElementById("f-stock").value = producto.stock;
    document.getElementById("f-categorias").value = producto.categorias.join(", ");
    document.getElementById("f-fecha").value = producto.fechaIngreso || "";
    document.getElementById("f-activo").value = String(producto.activo);
    document.getElementById("f-prov-nombre").value = producto.proveedor ? producto.proveedor.nombre : "";
    document.getElementById("f-prov-id").value = producto.proveedor ? producto.proveedor.id : "";
  } else {
    document.getElementById("titulo-modal").textContent = "Nuevo producto";
    document.getElementById("f-nombre").value = "";
    document.getElementById("f-precio").value = "";
    document.getElementById("f-stock").value = "";
    document.getElementById("f-categorias").value = "";
    document.getElementById("f-prov-nombre").value = "";
    document.getElementById("f-prov-id").value = "";
    document.getElementById("f-fecha").value = new Date().toISOString().split("T")[0];
    document.getElementById("f-activo").value = "true";
  }
}

function cerrarModal() {
  document.getElementById("fondo-modal").style.display = "none";
  idEditando = null;
}

function guardarProducto() {
  let nombre = document.getElementById("f-nombre").value.trim();
  let precio = document.getElementById("f-precio").value;
  let stock = document.getElementById("f-stock").value;

  if (nombre === "") {
    mostrarToast("El nombre es obligatorio.");
    return;
  }
  if (precio === "" || isNaN(Number(precio))) {
    mostrarToast("El precio no es válido.");
    return;
  }
  if (stock === "" || isNaN(Number(stock))) {
    mostrarToast("El stock no es válido.");
    return;
  }

  
  let categoriasTexto = document.getElementById("f-categorias").value;
  let categorias = [];
  let partes = categoriasTexto.split(",");
  for (let i = 0; i < partes.length; i++) {
    let cat = partes[i].trim();
    if (cat !== "") {
      categorias.push(cat);
    }
  }

  
  let provNombre = document.getElementById("f-prov-nombre").value.trim();
  let provId = parseInt(document.getElementById("f-prov-id").value) || null;
  let proveedor = null;
  if (provNombre !== "") {
    proveedor = { id: provId, nombre: provNombre };
  }

  if (idEditando !== null) {
    
    for (let i = 0; i < productos.length; i++) {
      if (productos[i].id === idEditando) {
        productos[i].nombre = nombre;
        productos[i].precio = Number(precio);
        productos[i].stock = Number(stock);
        productos[i].categorias = categorias;
        productos[i].proveedor = proveedor;
        productos[i].fechaIngreso = document.getElementById("f-fecha").value;
        productos[i].activo = document.getElementById("f-activo").value === "true";
        break;
      }
    }
    mostrarToast("Producto actualizado.");
  } else {
    
    let nuevo = {
      id: nuevoId(),
      nombre: nombre,
      precio: Number(precio),
      stock: Number(stock),
      activo: document.getElementById("f-activo").value === "true",
      fechaIngreso: document.getElementById("f-fecha").value,
      categorias: categorias,
      proveedor: proveedor
    };
    productos.push(nuevo);
    mostrarToast("Producto creado.");
  }

  cerrarModal();
  guardarStorage();
  renderizar();
}




function toggleActivo(id) {
  for (let i = 0; i < productos.length; i++) {
    if (productos[i].id === id) {
      productos[i].activo = !productos[i].activo;
      break;
    }
  }
  guardarStorage();
  renderizar();
}




function pedirConfirmacion(id) {
  idAEliminar = id;
  let producto = null;
  for (let i = 0; i < productos.length; i++) {
    if (productos[i].id === id) {
      producto = productos[i];
      break;
    }
  }
  document.getElementById("nombre-a-eliminar").textContent = producto ? producto.nombre : "este producto";
  document.getElementById("fondo-confirmar").style.display = "block";
}

function cerrarConfirmar() {
  document.getElementById("fondo-confirmar").style.display = "none";
  idAEliminar = null;
}

function confirmarEliminar() {
  let nuevosProductos = [];
  for (let i = 0; i < productos.length; i++) {
    if (productos[i].id !== idAEliminar) {
      nuevosProductos.push(productos[i]);
    }
  }
  productos = nuevosProductos;
  cerrarConfirmar();
  guardarStorage();
  mostrarToast("Producto eliminado.");
  renderizar();
}




function mostrarToast(mensaje) {
  let toast = document.getElementById("toast");
  toast.textContent = mensaje;
  toast.style.display = "block";
  setTimeout(function() {
    toast.style.display = "none";
  }, 2500);
}




renderizar();